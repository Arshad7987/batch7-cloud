package com.xoriant.manager.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.xoriant.manager.entity.Branch;

public interface BranchDao extends JpaRepository<Branch, Integer> {

}
