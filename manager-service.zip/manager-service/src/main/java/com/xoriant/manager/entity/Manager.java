package com.xoriant.manager.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;



@Entity(name = "manager")

public class Manager {
	@Id
	@GeneratedValue
	@JsonIgnore
	private int managerId;
	@OneToOne(cascade = CascadeType.REFRESH)
	@JoinColumn(name = "branchId")
	private Branch branch;

	@OneToMany(cascade = CascadeType.REFRESH)
	@JoinTable(name = "manager_Customer", joinColumns = { @JoinColumn(name = "managerId") }, inverseJoinColumns = {
			@JoinColumn(name = "customerId") })
	private List<Customer> customer;

	@OneToOne(cascade = CascadeType.REFRESH)
	@JoinColumn(name = "adressId")
	private Address address;

	public int getManagerId() {
		return managerId;
	}

	public void setManagerId(int managerId) {
		this.managerId = managerId;
	}

	public Branch getBranch() {
		return branch;
	}

	public void setBranch(Branch branch) {
		this.branch = branch;
	}

	public List<Customer> getCustomer() {
		return customer;
	}

	public void setCustomer(List<Customer> customer) {
		this.customer = customer;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

}
