package com.xoriant.manager.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.client.RestTemplate;

import com.xoriant.manager.dao.BranchDao;
import com.xoriant.manager.dao.CustomerDao;
import com.xoriant.manager.dao.ManagerDao;
import com.xoriant.manager.entity.Address;
import com.xoriant.manager.entity.Branch;
import com.xoriant.manager.entity.Customer;
import com.xoriant.manager.entity.Manager;
import com.xoriant.manager.entity.PersonInfo;

@Service
public class ManagerServiceImpl {
	@Autowired
	private ManagerDao managerDao;
	@Autowired
	private BranchDao branchDao;
	@Autowired
	private CustomerDao customerDao;


	public Manager save(Manager manager) {

		managerDao.save(manager);
		return manager;

	}

	public Branch save(Branch branch) {

		return branchDao.save(branch);

	}

	public Customer save(Customer customer) {

		customerDao.save(customer);
		return customer;

	}

	public Branch find(int branchId) {
		return branchDao.findById(branchId).orElse(null);
	}

}
