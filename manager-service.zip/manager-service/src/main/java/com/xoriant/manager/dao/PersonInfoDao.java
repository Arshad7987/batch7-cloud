package com.xoriant.manager.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.xoriant.manager.entity.PersonInfo;

public interface PersonInfoDao extends JpaRepository<PersonInfo, Integer> {

}
