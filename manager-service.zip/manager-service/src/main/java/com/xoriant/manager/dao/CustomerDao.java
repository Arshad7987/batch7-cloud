package com.xoriant.manager.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.xoriant.manager.entity.Customer;

public interface CustomerDao extends JpaRepository<Customer, Integer>{

}
