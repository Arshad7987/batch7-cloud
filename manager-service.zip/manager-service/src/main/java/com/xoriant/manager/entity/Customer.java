package com.xoriant.manager.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;


import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;



@Entity(name="customer")

public class Customer {
	@Id
	@GeneratedValue

	private int customerId;
	@OneToOne(cascade = CascadeType.REFRESH,fetch = FetchType.EAGER)
	private PersonInfo personId;

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public PersonInfo getPersonId() {
		return personId;
	}

	public void setPersonId(PersonInfo personId) {
		this.personId = personId;
	}

}
