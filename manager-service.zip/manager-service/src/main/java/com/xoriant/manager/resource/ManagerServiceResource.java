package com.xoriant.manager.resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.xoriant.manager.entity.Branch;
import com.xoriant.manager.entity.Customer;
import com.xoriant.manager.entity.Manager;
import com.xoriant.manager.service.ManagerServiceImpl;

@RestController
@RequestMapping("/api/managerservice")
@CrossOrigin
@RefreshScope
public class ManagerServiceResource {
	@Autowired
	private ManagerServiceImpl ms;

	@PostMapping("/save/manager")
	public Manager save(@RequestBody Manager manager) {
		return ms.save(manager);
	}

	@PostMapping("/save/branch")
	public Branch save(@RequestBody Branch branch) {
		return ms.save(branch);
	}
	@PostMapping("/save/customer")
	public Customer save(@RequestBody Customer customer) {
		return ms.save(customer);
	}
	@GetMapping("/{branchId}")
	public Branch find(@PathVariable int branchId) {
		return ms.find(branchId);
	}
}
