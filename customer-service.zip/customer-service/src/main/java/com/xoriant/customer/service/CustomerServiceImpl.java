package com.xoriant.customer.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xoriant.customer.dao.AddressDao;
import com.xoriant.customer.dao.PersonInfoDao;
import com.xoriant.customer.entity.Address;
import com.xoriant.customer.entity.PersonInfo;

@Service
public class CustomerServiceImpl {
	@Autowired
	private AddressDao addressDao;
	@Autowired
	private PersonInfoDao personDao;
	
	public Address save(Address address) {
		return addressDao.save(address);
	}
	public PersonInfo save(PersonInfo person) {
		return personDao.save(person);
	}
	
	public PersonInfo findById(int personId) {
		return personDao.findById(personId).orElse(null);
	}
public Address addressById(int adressId) {
	return addressDao.findById(adressId).orElse(null);
}

}
