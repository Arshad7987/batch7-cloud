package com.xoriant.customer.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.xoriant.customer.entity.PersonInfo;

public interface CustomerDao extends JpaRepository<PersonInfo, Integer> {

}
