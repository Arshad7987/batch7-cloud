package com.xoriant.customer.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.xoriant.customer.entity.PersonInfo;

public interface PersonInfoDao extends JpaRepository<PersonInfo, Integer> {

}
