package com.xoriant.customer.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.xoriant.customer.entity.Address;

public interface AddressDao extends JpaRepository<Address, Integer>{

}
