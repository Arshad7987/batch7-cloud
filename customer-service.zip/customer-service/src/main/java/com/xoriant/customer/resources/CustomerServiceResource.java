package com.xoriant.customer.resources;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.xoriant.customer.entity.Address;
import com.xoriant.customer.entity.PersonInfo;
import com.xoriant.customer.service.CustomerServiceImpl;

@RestController
@RequestMapping("/api/customer")
@CrossOrigin
@RefreshScope
public class CustomerServiceResource {
@Autowired
	private CustomerServiceImpl cs;

	@PostMapping("/save/address")
	public Address address(@RequestBody Address address) {
		return cs.save(address);
	}
	@PostMapping("/save/info")
	public PersonInfo save(@RequestBody PersonInfo personInfo) {
		return cs.save(personInfo);
	}
	
	@GetMapping("/get/{personId}")
	public PersonInfo findById(@PathVariable int personId) {
		return cs.findById(personId);
	}

	@GetMapping("/get/address/{adressId}")
	public Address findaddressById(@PathVariable int adressId) {
		return cs.addressById(adressId);
	}
}
