package com.xoriant.account.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;



@Entity(name = "branch")
public class Branch {
	@Id
	@GeneratedValue

	private int branchId;

	private String branchName;
	private String ifscCode;
	private String micrCode;
	@OneToOne(cascade = CascadeType.REFRESH)
	private Address addressAdressIdAdressId;

	public Branch() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Branch(int branchId, String branchName, String ifscCode, String micrCode, Address addressAdressIdAdressId) {
		super();
		this.branchId = branchId;
		this.branchName = branchName;
		this.ifscCode = ifscCode;
		this.micrCode = micrCode;
		this.addressAdressIdAdressId = addressAdressIdAdressId;
	}

	public Address getAddressAdressIdAdressId() {
		return addressAdressIdAdressId;
	}

	public void setAddressAdressIdAdressId(Address addressAdressIdAdressId) {
		this.addressAdressIdAdressId = addressAdressIdAdressId;
	}

	public int getBranchId() {
		return branchId;
	}

	public void setBranchId(int branchId) {
		this.branchId = branchId;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getIfscCode() {
		return ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	public String getMicrCode() {
		return micrCode;
	}

	public void setMicrCode(String micrCode) {
		this.micrCode = micrCode;
	}

	@Override
	public String toString() {
		return "Branch [branchId=" + branchId + ", branchName=" + branchName + ", ifscCode=" + ifscCode + ", micrCode="
				+ micrCode + ", addressAdressIdAdressId=" + addressAdressIdAdressId + "]";
	}

}
