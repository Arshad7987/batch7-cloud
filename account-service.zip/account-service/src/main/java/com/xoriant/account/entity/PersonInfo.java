package com.xoriant.account.entity;

import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;



@Entity
public class PersonInfo {
	
	public enum Gender{ 
	    MALE, FEMALE 
	}
	@Id
	@GeneratedValue
	private int personId;
	private String personName;
	@Enumerated(EnumType.STRING)
    private Gender gender;
	private LocalDate dateOfBirth;
	private String emailAddress;
	private long phoneNumber;
	@OneToOne(cascade = CascadeType.REFRESH)
	private Address addressId;
	public int getPersonId() {
		return personId;
	}
	public void setPersonId(int personId) {
		this.personId = personId;
	}
	public String getPersonName() {
		return personName;
	}
	public void setPersonName(String personName) {
		this.personName = personName;
	}
	public Gender getGender() {
		return gender;
	}
	public void setGender(Gender gender) {
		this.gender = gender;
	}
	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public long getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public Address getAdress() {
		return addressId;
	}
	public void setAdressId(Address adressId) {
		this.addressId = adressId;
	}

}
