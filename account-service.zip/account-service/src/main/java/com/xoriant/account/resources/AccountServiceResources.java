package com.xoriant.account.resources;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.xoriant.account.entity.Account;
import com.xoriant.account.service.AccountServiceImpl;

@RestController
@RequestMapping("/api/account")
public class AccountServiceResources {
	@Autowired
	private AccountServiceImpl as;
	
	@PostMapping("/save")
	public Account save(@RequestBody Account account) {
		return as.save(account);
	}

	@GetMapping("/get/{accountId}")
	public Account findById(@PathVariable int accountId) {
		return as.findById(accountId);

}
}
