package com.xoriant.account.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xoriant.account.dao.AccountDao;
import com.xoriant.account.entity.Account;

@Service
public class AccountServiceImpl {
	@Autowired
	private AccountDao accountDao;
	

	public Account save(Account account) {
		return accountDao.save(account);
	}
	
		
	
	public Account findById(int accountNo) {
		return accountDao.findById(accountNo).orElse(null);
	}


}
